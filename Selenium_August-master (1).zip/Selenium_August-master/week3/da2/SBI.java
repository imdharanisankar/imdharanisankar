package week3.da2;

public class SBI implements RBI{

	public void minimumBalance() {
		System.out.println("2500");
	}

	public void maximumLoanAmount() {
		System.out.println("600000");
	} 
	
	
	public void provideLoalForITProfessional() {
		System.out.println("8.0 %");
	}

	@Override
	public void getCibileScore() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rules() {
		// TODO Auto-generated method stub
		
	}

}
