package week3.da2;

public interface Government {

	public void rules();
	
}
