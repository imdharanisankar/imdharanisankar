package week3.da2;

public interface Cibil {

	public void getCibileScore();
	
	
}
