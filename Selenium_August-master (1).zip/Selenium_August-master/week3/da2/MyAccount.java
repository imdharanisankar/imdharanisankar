package week3.da2;

public class MyAccount extends AxisBank{

	public void name() {
		applyBrake();
		minimumBalance();
		getCibileScore();
		rules();
	}
	
	
	
}
