package week3.da2;

import week3.day1.Car;

public class AxisBank extends Car implements RBI{

	public void minimumBalance() {
		System.out.println("5000");
	}

	public void maximumLoanAmount() {
		System.out.println("500000");
	}

	public void provideGoldLoan() {
		System.out.println("9.0 %");
		System.out.println(minBalance);
		//minBalance = 1000;
	}

	@Override
	public void getCibileScore() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rules() {
		// TODO Auto-generated method stub
		
	}


	
	
}
