package week3.day1;

public class Bajaj extends Auto{

	
	public void switchOnWIFI() {
		System.out.println("WIFI On");
	}
	
	public void localRun() {
		System.out.println(numberOfWheels);
		applyBrake();
		soundHorn();
		turnMeter();
	}
	
	
}
