package week3.day1;

public class Vehicle {


	public void applyBrake() {
		System.out.println("normal brake");
	}


	public void soundHorn() {
		System.out.println("single Horn");
	}

}
