package testng.day1;

import org.testng.annotations.Test;

public class TestCase2 extends BaseClass{
	
	@Test
	public void test3() {
		System.out.println("test3");

	}

	@Test
	public void test4() {
		System.out.println("test4");

	}
	
}
