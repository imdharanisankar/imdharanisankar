package week1.day2;

import week1.day1.LearnAccessModifier;

public class CallDefaultValue {
public static void main(String[] args) {
LearnAccessModifier obj = new LearnAccessModifier();
System.out.println(obj.text1);
//System.out.println(obj.text3);
}
}
