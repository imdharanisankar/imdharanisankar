package week1.day2;

public class LearnConditions1 {
public static void main(String[] args) {
	int age = 15;
	if(age >= 18) {
		// true block
		System.out.println("Allowed Inside");
	}
	else
	{
		// false block
		System.out.println("Not Allowed");
	}
}
}
