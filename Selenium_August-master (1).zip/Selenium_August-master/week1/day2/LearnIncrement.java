package week1.day2;

public class LearnIncrement {
public static void main(String[] args) {
	int i = 0;
	System.out.println(i++);
	System.out.println(i);
	System.out.println(++i);
	int j = 5;
	System.out.println(j--);
	System.out.println(j);
	System.out.println(--j);
}
}
