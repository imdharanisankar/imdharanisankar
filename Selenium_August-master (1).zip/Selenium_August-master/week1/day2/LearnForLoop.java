package week1.day2;

public class LearnForLoop {
public static void main(String[] args) {
	// Syntax to write a for loop
	//for(initialisation;condition;increment/decrement){ }
	for(int i = 1; i <= 10;i=i+1) {
	System.out.println(i);
	}
}
}
